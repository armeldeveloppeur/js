require('babel-register')
const mysql = require('mysql')
const morgan = require('morgan')('dev')
const express = require('express')
const twig = require('twig')
const bodyParser = require('body-parser')
const serve_static = require('serve-static')
const axios = require('axios')


const app = express()
const port = 8081


app.use(morgan)
app.use(bodyParser.json())
app.use(bodyParser.urlencoded({ extended:true }))


// module.exports = (app, config) => {

// app.set('port', 8081);
// app.set('views', './server/views//');
// app.set('view engine', 'pug');



// app.use('/stylesheets', express.static('./builds/app/stylesheets'));
app.use(express.static('public'));
// }


app.get('/',(req, res) => {
	res.sendFile(__dirname+'/views/index.html')
	// res.render('index.twig')
})

// app.get('/menu.html',(req, res) => {
// 	res.sendFile(__dirname+'/views/menu.html')
// 	// res.render('index.twig')
// })

app.get('/afrique.html',(req, res) => {
	res.sendFile(__dirname+'/views/afrique.html')
	// axios.get('http://localhost:8081/afrique.html')
	// res.render('index.twig')
}) 

app.get('/menu.html',(req, res) => {
	res.sendFile(__dirname+'/views/menu.html')
	// res.render('index.twig')
})

app.get('/best.html',(req, res) => {
	res.sendFile(__dirname+'/views/best.html')
	// res.render('index.twig')
})

// app.get('/continent',(req, res) => {
// 	axios.get('http://localhost:8081/api/v1/continent')
// 		.then((response) => {
// 		  	if (response.data.status == 'success') 
// 		  	{
// 		  		console.log(response.data.result)
// 		  	}
// 		  	else 
// 		  	{

// 		  	}
// 		  })

// 		  // .catch((err) => {
// 		  // 	console.log(err.message)
// 		  // })
// })


// const db = mysql.createConnection({
// 	host: 'localhost',
// 	database: 'alimentation',
// 	user: 'root',
// 	password: '',

// })

// db.connect((err) => {
//   if (err) {
//     console.log('err.message');
//     return;
//   }
//   else
//   {


// 	console.log('connecté');

// 	db.query('SELECT * FROM `continent`', function (error, results) {

// 		if (err) 
// 		{
// 			console.log (err.message)
// 		}
// 		else
// 		{
// 			console.log(results)
// 		}

// 	})
//   }
// });	

app.listen(port, () => console.log('Connecté au port' + port))